/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
// APPOINTMENT CLASS
public class Appointment {
    private String appointmentId;
    private String patientId;
    private String doctorId;
    private String date;
    private String time;

    public Appointment(String appointmentId, String patientId,
                       String doctorId, String date, String time) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
    }

    // Getters
    public String getAppointmentId() { return appointmentId; }
    public String getPatientId()     { return patientId; }
    public String getDoctorId()      { return doctorId; }
    public String getDate()          { return date; }
    public String getTime()          { return time; }

    // Save to file: appId,patientId,doctorId,date,time
    public String toFileString() {
        return appointmentId + "," + patientId + "," + doctorId + "," + date + "," + time;
    }

    // Load from file
    public static Appointment fromFileString(String line) {
        String[] parts = line.split(",");
        return new Appointment(parts[0], parts[1], parts[2], parts[3], parts[4]);
    }

    @Override
    public String toString() {
        return "Appt#" + appointmentId + " | Patient: " + patientId
               + " | Doctor: " + doctorId + " | Date: " + date + " | Time: " + time;
    }
}