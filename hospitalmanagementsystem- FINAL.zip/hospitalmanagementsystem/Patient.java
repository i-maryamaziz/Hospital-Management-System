/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
// PATIENT CLASS - extends Person (Inheritance)
public class Patient extends Person {
    private String patientId;
    private String disease;

    public Patient(String patientId, String name, int age, String phone, String disease) {
        super(name, age, phone);   // calls Person's constructor
        this.patientId = patientId;
        this.disease = disease;
    }

    // Getters and Setters
    public String getPatientId()       { return patientId; }
    public String getDisease()         { return disease; }
    public void setDisease(String d)   { this.disease = d; }

    // Polymorphism - our own version of getRole()
    @Override
    public String getRole() { return "Patient"; }

    // Save to file: id,name,age,phone,disease
    public String toFileString() {
        return patientId + "," + getName() + "," + getAge() + "," + getPhone() + "," + disease;
    }

    // Load from file
    public static Patient fromFileString(String line) {
        String[] parts = line.split(",");
        return new Patient(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4]);
    }

    @Override
    public String toString() {
        return patientId + " | " + super.toString() + " | Disease: " + disease;
    }
}
