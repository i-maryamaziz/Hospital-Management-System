/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
// DOCTOR CLASS - extends Person (Inheritance)
public class Doctor extends Person {
    private String doctorId;
    private String specialization;
    private String availability;

    public Doctor(String doctorId, String name, int age, String phone,
                  String specialization, String availability) {
        super(name, age, phone);   // calls Person's constructor
        this.doctorId = doctorId;
        this.specialization = specialization;
        this.availability = availability;
    }

    // Getters and Setters
    public String getDoctorId()              { return doctorId; }
    public String getSpecialization()         { return specialization; }
    public void setSpecialization(String s)   { this.specialization = s; }
    public String getAvailability()           { return availability; }
    public void setAvailability(String a)     { this.availability = a; }

    // Polymorphism - our own version of getRole()
    @Override
    public String getRole() { return "Doctor"; }

    // Save to file: id,name,age,phone,specialization,availability
    public String toFileString() {
        return doctorId + "," + getName() + "," + getAge() + "," + getPhone()
               + "," + specialization + "," + availability;
    }

    // Load from file
    public static Doctor fromFileString(String line) {
        String[] parts = line.split(",");
        return new Doctor(parts[0], parts[1], Integer.parseInt(parts[2]),
                          parts[3], parts[4], parts[5]);
    }

    @Override
    public String toString() {
        return doctorId + " | " + super.toString()
               + " | Specialization: " + specialization
               + " | Available: " + availability;
    }
}