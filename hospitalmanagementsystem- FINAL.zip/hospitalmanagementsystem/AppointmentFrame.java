/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// APPOINTMENT MANAGEMENT SCREEN
public class AppointmentFrame extends JFrame {

    private JTextField apptIdField, patientIdField, doctorIdField, dateField, timeField;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Appointment> appointments;

    public AppointmentFrame() {
        setTitle("Appointment Management");
        setSize(750, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        appointments = FileManager.loadAppointments();
        buildUI();
        refreshTable();
        setVisible(true);
    }

    private void buildUI() {
        setLayout(new BorderLayout(10, 10));

        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(new Color(255, 153, 0));
        JLabel lbl = new JLabel("Appointment Management");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.BOLD, 16));
        header.add(lbl);
        add(header, BorderLayout.NORTH);

        // ── Input Form ──────────────────────────────────
        JPanel form = new JPanel(new GridLayout(6, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Book Appointment"));
        form.setPreferredSize(new Dimension(300, 230));

        form.add(new JLabel("Appointment ID:"));
        apptIdField = new JTextField();
        form.add(apptIdField);

        form.add(new JLabel("Patient ID:"));
        patientIdField = new JTextField();
        form.add(patientIdField);

        form.add(new JLabel("Doctor ID:"));
        doctorIdField = new JTextField();
        form.add(doctorIdField);

        form.add(new JLabel("Date (DD/MM/YYYY):"));
        dateField = new JTextField();
        form.add(dateField);

        form.add(new JLabel("Time (e.g. 10:00 AM):"));
        timeField = new JTextField();
        form.add(timeField);

        JButton bookBtn = new JButton("Book Appointment");
        bookBtn.setBackground(new Color(255, 153, 0));
        bookBtn.setForeground(Color.WHITE);
        form.add(bookBtn);

        JButton clearBtn = new JButton("Clear");
        form.add(clearBtn);

        // ── Table ───────────────────────────────────────
        String[] cols = {"Appt ID", "Patient ID", "Doctor ID", "Date", "Time"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(table);

        // ── Buttons ─────────────────────────────────────
        JButton cancelBtn = new JButton("Cancel Appointment");
        cancelBtn.setBackground(new Color(220, 53, 69));
        cancelBtn.setForeground(Color.WHITE);

        JButton showDoctorsBtn = new JButton("View Available Doctors");
        showDoctorsBtn.setBackground(new Color(0, 123, 255));
        showDoctorsBtn.setForeground(Color.WHITE);

        // ── Right Panel ─────────────────────────────────
        JPanel rightPanel = new JPanel(new BorderLayout(5, 5));
        rightPanel.add(showDoctorsBtn, BorderLayout.NORTH);
        rightPanel.add(scroll, BorderLayout.CENTER);
        rightPanel.add(cancelBtn, BorderLayout.SOUTH);

        add(form, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        // ── Event Handling ──────────────────────────────
        bookBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bookAppointment();
            }
        });

        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        cancelBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelAppointment();
            }
        });

        showDoctorsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showDoctors();
            }
        });
    }

    private void bookAppointment() {
        String apptId = apptIdField.getText().trim();
        String pId    = patientIdField.getText().trim();
        String dId    = doctorIdField.getText().trim();
        String date   = dateField.getText().trim();
        String time   = timeField.getText().trim();

        if (apptId.isEmpty() || pId.isEmpty() || dId.isEmpty()
                || date.isEmpty() || time.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }

        // Check duplicate appointment ID
        for (Appointment a : appointments) {
            if (a.getAppointmentId().equals(apptId)) {
                JOptionPane.showMessageDialog(this, "Appointment ID already exists!");
                return;
            }
        }

        // Check patient exists
        List<Patient> patients = FileManager.loadPatients();
        boolean patientFound = false;
        for (Patient p : patients) {
            if (p.getPatientId().equals(pId)) {
                patientFound = true;
                break;
            }
        }
        if (!patientFound) {
            JOptionPane.showMessageDialog(this, "Patient ID not found! Add the patient first.");
            return;
        }

        // Check doctor exists
        List<Doctor> doctors = FileManager.loadDoctors();
        boolean doctorFound = false;
        for (Doctor d : doctors) {
            if (d.getDoctorId().equals(dId)) {
                doctorFound = true;
                break;
            }
        }
        if (!doctorFound) {
            JOptionPane.showMessageDialog(this, "Doctor ID not found! Add the doctor first.");
            return;
        }

        appointments.add(new Appointment(apptId, pId, dId, date, time));
        FileManager.saveAppointments(appointments);
        refreshTable();
        clearFields();
        JOptionPane.showMessageDialog(this, "Appointment booked successfully!");
    }

    private void cancelAppointment() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select an appointment first.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Cancel appointment " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            appointments.removeIf(a -> a.getAppointmentId().equals(id));
            FileManager.saveAppointments(appointments);
            refreshTable();
        }
    }

    private void showDoctors() {
        List<Doctor> doctors = FileManager.loadDoctors();
        if (doctors.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No doctors added yet.");
            return;
        }
        String message = "Available Doctors:\n\n";
        for (Doctor d : doctors) {
            message = message + "ID: " + d.getDoctorId()
                    + " | Name: " + d.getName()
                    + " | Specialization: " + d.getSpecialization()
                    + " | Available: " + d.getAvailability() + "\n";
        }
        JOptionPane.showMessageDialog(this, message, "Doctors",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Appointment a : appointments) {
            tableModel.addRow(new Object[]{
                a.getAppointmentId(), a.getPatientId(),
                a.getDoctorId(), a.getDate(), a.getTime()
            });
        }
    }

    private void clearFields() {
        apptIdField.setText("");
        patientIdField.setText("");
        doctorIdField.setText("");
        dateField.setText("");
        timeField.setText("");
    }
}