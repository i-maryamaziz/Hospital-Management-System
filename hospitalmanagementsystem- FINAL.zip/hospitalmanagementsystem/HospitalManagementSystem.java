/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.SwingUtilities;

// MAIN CLASS - entry point of the program
public class HospitalManagementSystem {
    public static void main(String[] args) {
        // Run GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame();   // start with login screen
            }
        });
    }
}
