/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// MAIN MENU - shown after login
public class MainMenuFrame extends JFrame {

    public MainMenuFrame() {
        setTitle("Hospital Management System - Main Menu");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        JPanel main = new JPanel(new BorderLayout());

        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(new Color(0, 102, 153));
        header.setPreferredSize(new Dimension(500, 60));
        JLabel title = new JLabel("Hospital Management System");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        header.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 15));
        header.add(title);
        main.add(header, BorderLayout.NORTH);

        // ── Buttons Panel ────────────────────────────────
        JPanel btnPanel = new JPanel(new GridLayout(3, 2, 20, 20));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JButton patientBtn     = makeButton("Patient Management",  new Color(0, 123, 255));
        JButton doctorBtn      = makeButton("Doctor Management",     new Color(40, 167, 69));
        JButton appointmentBtn = makeButton("Appointments",         new Color(255, 153, 0));
        JButton viewAllBtn     = makeButton("View All Records",     new Color(108, 117, 125));
        JButton logoutBtn      = makeButton("Logout",               new Color(220, 53, 69));
        JButton exitBtn        = makeButton("Exit",                  new Color(52, 58, 64));

        btnPanel.add(patientBtn);
        btnPanel.add(doctorBtn);
        btnPanel.add(appointmentBtn);
        btnPanel.add(viewAllBtn);
        btnPanel.add(logoutBtn);
        btnPanel.add(exitBtn);

        main.add(btnPanel, BorderLayout.CENTER);
        add(main);

        // ── Event Handling ──────────────────────────────
        patientBtn.addActionListener(e -> new PatientFrame());
        doctorBtn.addActionListener(e -> new DoctorFrame());
        appointmentBtn.addActionListener(e -> new AppointmentFrame());
        viewAllBtn.addActionListener(e -> showAllRecords());

        logoutBtn.addActionListener(e -> {
            new LoginFrame();
            dispose();
        });

        exitBtn.addActionListener(e -> System.exit(0));
    }

    // Helper to create styled buttons
    private JButton makeButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 13));
        btn.setFocusPainted(false);
        return btn;
    }

    // View all records in one place
    private void showAllRecords() {
        java.util.List<Patient>     patients     = FileManager.loadPatients();
        java.util.List<Doctor>      doctors      = FileManager.loadDoctors();
        java.util.List<Appointment> appointments = FileManager.loadAppointments();

        StringBuilder sb = new StringBuilder();
        sb.append("=== PATIENTS (").append(patients.size()).append(") ===\n");
        for (Patient p : patients)     sb.append(p).append("\n");

        sb.append("\n=== DOCTORS (").append(doctors.size()).append(") ===\n");
        for (Doctor d : doctors)       sb.append(d).append("\n");

        sb.append("\n=== APPOINTMENTS (").append(appointments.size()).append(") ===\n");
        for (Appointment a : appointments) sb.append(a).append("\n");

        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(600, 400));

        JOptionPane.showMessageDialog(this, scroll, "All Records",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
