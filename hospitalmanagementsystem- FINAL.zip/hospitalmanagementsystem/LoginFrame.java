/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// LOGIN SCREEN - first window the user sees
public class LoginFrame extends JFrame {

    private JTextField userField;
    private JPasswordField passField;

    public LoginFrame() {
        setTitle("Hospital Management System - Login");
        setSize(400, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        JPanel main = new JPanel(new BorderLayout());

        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(new Color(0, 102, 153));
        JLabel title = new JLabel("Hospital Management System");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        header.add(title);
        main.add(header, BorderLayout.NORTH);

        // ── Form ────────────────────────────────────────
        JPanel form = new JPanel(new GridLayout(3, 2, 10, 15));
        form.setBorder(BorderFactory.createEmptyBorder(30, 40, 10, 40));

        form.add(new JLabel("Username:"));
        userField = new JTextField();
        form.add(userField);

        form.add(new JLabel("Password:"));
        passField = new JPasswordField();
        form.add(passField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(0, 153, 76));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 13));
        form.add(new JLabel(""));
        form.add(loginBtn);

        main.add(form, BorderLayout.CENTER);

        // ── Hint label ──────────────────────────────────
        JLabel hint = new JLabel("Default: ham / ham123", JLabel.CENTER);
        hint.setForeground(Color.GRAY);
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        main.add(hint, BorderLayout.SOUTH);

        add(main);

        // ── Event Handling ──────────────────────────────
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkLogin();
            }
        });

        passField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkLogin();
            }
        });
    }

    private void checkLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword()).trim();

        if (user.equals("ham") && pass.equals("ham123")) {
            JOptionPane.showMessageDialog(this, "Login Successful! Welcome, HAM.");
            new MainMenuFrame();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password!",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
            passField.setText("");
        }
    }
}