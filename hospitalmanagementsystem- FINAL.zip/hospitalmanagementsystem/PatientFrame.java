/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// PATIENT MANAGEMENT SCREEN
public class PatientFrame extends JFrame {

    private JTextField idField, nameField, ageField, phoneField, diseaseField, searchField;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Patient> patients;

    public PatientFrame() {
        setTitle("Patient Management");
        setSize(750, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        patients = FileManager.loadPatients();
        buildUI();
        refreshTable();
        setVisible(true);
    }

    private void buildUI() {
        setLayout(new BorderLayout(10, 10));

        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(new Color(0, 123, 255));
        JLabel lbl = new JLabel("Patient Management");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.BOLD, 16));
        header.add(lbl);
        add(header, BorderLayout.NORTH);

        // ── Input Form ──────────────────────────────────
        JPanel form = new JPanel(new GridLayout(7, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Add Patient"));
        form.setPreferredSize(new Dimension(300, 220));

        form.add(new JLabel("Patient ID:"));
        idField = new JTextField();
        form.add(idField);

        form.add(new JLabel("Name:"));
        nameField = new JTextField();
        form.add(nameField);

        form.add(new JLabel("Age:"));
        ageField = new JTextField();
        form.add(ageField);

        form.add(new JLabel("Phone:"));
        phoneField = new JTextField();
        form.add(phoneField);

        form.add(new JLabel("Disease:"));
        diseaseField = new JTextField();
        form.add(diseaseField);

        JButton addBtn = new JButton("Add Patient");
        addBtn.setBackground(new Color(40, 167, 69));
        addBtn.setForeground(Color.WHITE);
        form.add(addBtn);

        JButton updateBtn = new JButton("Update Patient");
        updateBtn.setBackground(new Color(0, 123, 255));
        updateBtn.setForeground(Color.WHITE);
        form.add(updateBtn);

        JButton clearBtn = new JButton("Clear");
        form.add(clearBtn);

        // ── Search Bar ──────────────────────────────────
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search by Name:"));
        searchField = new JTextField(15);
        searchPanel.add(searchField);
        JButton searchBtn = new JButton("Search");
        searchPanel.add(searchBtn);
        JButton showAllBtn = new JButton("Show All");
        searchPanel.add(showAllBtn);

        // ── Table ───────────────────────────────────────
        String[] cols = {"ID", "Name", "Age", "Phone", "Disease"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(table);

        // ── Delete Button ───────────────────────────────
        JButton deleteBtn = new JButton("Delete Selected");
        deleteBtn.setBackground(new Color(220, 53, 69));
        deleteBtn.setForeground(Color.WHITE);

        // ── Right Panel ─────────────────────────────────
        JPanel rightPanel = new JPanel(new BorderLayout(5, 5));
        rightPanel.add(searchPanel, BorderLayout.NORTH);
        rightPanel.add(scroll, BorderLayout.CENTER);
        rightPanel.add(deleteBtn, BorderLayout.SOUTH);

        add(form, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        // ── Event Handling ──────────────────────────────
        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPatient();
            }
        });

        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
        
        updateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updatePatient();
            }
         });

        deleteBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletePatient();
            }
        });

        searchBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchPatient();
            }
        });

        showAllBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshTable();
            }
        });

        // Click table row to fill form
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                fillFormFromTable();
            }
        });
    }

    private void addPatient() {
        String id      = idField.getText().trim();
        String name    = nameField.getText().trim();
        String ageStr  = ageField.getText().trim();
        String phone   = phoneField.getText().trim();
        String disease = diseaseField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || ageStr.isEmpty()
                || phone.isEmpty() || disease.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }

        int age;
        try { age = Integer.parseInt(ageStr); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a number!");
            return;
        }

        for (Patient p : patients) {
            if (p.getPatientId().equals(id)) {
                JOptionPane.showMessageDialog(this, "Patient ID already exists!");
                return;
            }
        }

        Patient newPatient = new Patient(id, name, age, phone, disease);
        patients.add(newPatient);
        FileManager.savePatients(patients);
        refreshTable();
        clearFields();
        JOptionPane.showMessageDialog(this, "Patient added successfully!");
    }
    
    private void updatePatient() {
    String id      = idField.getText().trim();
    String name    = nameField.getText().trim();
    String ageStr  = ageField.getText().trim();
    String phone   = phoneField.getText().trim();
    String disease = diseaseField.getText().trim();

    // Check all fields are filled
    if (id.isEmpty() || name.isEmpty() || ageStr.isEmpty()
            || phone.isEmpty() || disease.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields!");
        return;
    }

    int age;
    try { age = Integer.parseInt(ageStr); }
    catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Age must be a number!");
        return;
    }

    // Find the patient with this ID and update them
    boolean found = false;
    for (int i = 0; i < patients.size(); i++) {
        if (patients.get(i).getPatientId().equals(id)) {
            patients.set(i, new Patient(id, name, age, phone, disease));
            found = true;
            break;
        }
    }

    if (!found) {
        JOptionPane.showMessageDialog(this, "Patient ID not found! Select a row first.");
        return;
    }

    FileManager.savePatients(patients);
       refreshTable();
        clearFields();
    JOptionPane.showMessageDialog(this, "Patient updated successfully!");
    }

    private void deletePatient() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a patient to delete.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete patient " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            patients.removeIf(p -> p.getPatientId().equals(id));
            FileManager.savePatients(patients);
            refreshTable();
            clearFields();
        }
    }

    private void searchPatient() {
        String keyword = searchField.getText().trim().toLowerCase();
        tableModel.setRowCount(0);
        for (Patient p : patients) {
            if (p.getName().toLowerCase().contains(keyword)) {
                tableModel.addRow(new Object[]{
                    p.getPatientId(), p.getName(), p.getAge(),
                    p.getPhone(), p.getDisease()
                });
            }
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Patient p : patients) {
            tableModel.addRow(new Object[]{
                p.getPatientId(), p.getName(), p.getAge(),
                p.getPhone(), p.getDisease()
            });
        }
    }

    private void fillFormFromTable() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText((String) tableModel.getValueAt(row, 0));
            nameField.setText((String) tableModel.getValueAt(row, 1));
            ageField.setText(tableModel.getValueAt(row, 2).toString());
            phoneField.setText((String) tableModel.getValueAt(row, 3));
            diseaseField.setText((String) tableModel.getValueAt(row, 4));
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        phoneField.setText("");
        diseaseField.setText("");
        searchField.setText("");
    }
}
