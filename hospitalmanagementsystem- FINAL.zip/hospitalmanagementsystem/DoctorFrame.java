/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// DOCTOR MANAGEMENT SCREEN
public class DoctorFrame extends JFrame {

    private JTextField idField, nameField, ageField, phoneField, specField, availField;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Doctor> doctors;

    public DoctorFrame() {
        setTitle("Doctor Management");
        setSize(800, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        doctors = FileManager.loadDoctors();
        buildUI();
        refreshTable();
        setVisible(true);
    }

    private void buildUI() {
        setLayout(new BorderLayout(10, 10));

        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(new Color(40, 167, 69));
        JLabel lbl = new JLabel("Doctor Management:");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.BOLD, 16));
        header.add(lbl);
        add(header, BorderLayout.NORTH);

        // ── Input Form ──────────────────────────────────
        JPanel form = new JPanel(new GridLayout(8, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Add Doctor"));
        form.setPreferredSize(new Dimension(310, 260));

        form.add(new JLabel("Doctor ID:"));
        idField = new JTextField();
        form.add(idField);

        form.add(new JLabel("Name:"));
        nameField = new JTextField();
        form.add(nameField);

        form.add(new JLabel("Age:"));
        ageField = new JTextField();
        form.add(ageField);

        form.add(new JLabel("Phone:"));
        phoneField = new JTextField();
        form.add(phoneField);

        form.add(new JLabel("Specialization:"));
        specField = new JTextField();
        form.add(specField);

        form.add(new JLabel("Availability:"));
        availField = new JTextField("Mon-Fri 9am-5pm");
        form.add(availField);

        JButton addBtn = new JButton("Add Doctor");
        addBtn.setBackground(new Color(40, 167, 69));
        addBtn.setForeground(Color.WHITE);
        form.add(addBtn);

        JButton updateBtn = new JButton("Update Doctor");
        updateBtn.setBackground(new Color(0, 123, 255));
        updateBtn.setForeground(Color.WHITE);
        form.add(updateBtn);

        JButton clearBtn = new JButton("Clear");
        form.add(clearBtn);
        // ── Table ───────────────────────────────────────
        String[] cols = {"ID", "Name", "Age", "Phone", "Specialization", "Availability"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(table);

        // ── Delete Button ───────────────────────────────
        JButton deleteBtn = new JButton("Delete Selected");
        deleteBtn.setBackground(new Color(220, 53, 69));
        deleteBtn.setForeground(Color.WHITE);

        // ── Right Panel ─────────────────────────────────
        JPanel rightPanel = new JPanel(new BorderLayout(5, 5));
        rightPanel.add(scroll, BorderLayout.CENTER);
        rightPanel.add(deleteBtn, BorderLayout.SOUTH);

        add(form, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        // ── Event Handling ──────────────────────────────
        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addDoctor();
            }
        });
        updateBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        updateDoctor();
    }
});
        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteDoctor();
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                fillForm();
            }
        });
    }

    private void addDoctor() {
        String id    = idField.getText().trim();
        String name  = nameField.getText().trim();
        String ageStr= ageField.getText().trim();
        String phone = phoneField.getText().trim();
        String spec  = specField.getText().trim();
        String avail = availField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || ageStr.isEmpty()
                || phone.isEmpty() || spec.isEmpty() || avail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }

        int age;
        try { age = Integer.parseInt(ageStr); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a number!");
            return;
        }

        for (Doctor d : doctors) {
            if (d.getDoctorId().equals(id)) {
                JOptionPane.showMessageDialog(this, "Doctor ID already exists!");
                return;
            }
        }

        doctors.add(new Doctor(id, name, age, phone, spec, avail));
        FileManager.saveDoctors(doctors);
        refreshTable();
        clearFields();
        JOptionPane.showMessageDialog(this, "Doctor added successfully!");
    }
    private void updateDoctor() {
    String id    = idField.getText().trim();
    String name  = nameField.getText().trim();
    String ageStr= ageField.getText().trim();
    String phone = phoneField.getText().trim();
    String spec  = specField.getText().trim();
    String avail = availField.getText().trim();

    // Check all fields are filled
    if (id.isEmpty() || name.isEmpty() || ageStr.isEmpty()
            || phone.isEmpty() || spec.isEmpty() || avail.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields!");
        return;
    }

    int age;
    try { age = Integer.parseInt(ageStr); }
    catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Age must be a number!");
        return;
    }

    // Find the doctor with this ID and update them
    boolean found = false;
    for (int i = 0; i < doctors.size(); i++) {
        if (doctors.get(i).getDoctorId().equals(id)) {
            doctors.set(i, new Doctor(id, name, age, phone, spec, avail));
            found = true;
            break;
        }
    }

    if (!found) {
        JOptionPane.showMessageDialog(this, "Doctor ID not found! Select a row first.");
        return;
    }

    FileManager.saveDoctors(doctors);
    refreshTable();
    clearFields();
    JOptionPane.showMessageDialog(this, "Doctor updated successfully!");
    }
    private void deleteDoctor() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a doctor first.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete doctor " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            doctors.removeIf(d -> d.getDoctorId().equals(id));
            FileManager.saveDoctors(doctors);
            refreshTable();
            clearFields();
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Doctor d : doctors) {
            tableModel.addRow(new Object[]{
                d.getDoctorId(), d.getName(), d.getAge(),
                d.getPhone(), d.getSpecialization(), d.getAvailability()
            });
        }
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText((String) tableModel.getValueAt(row, 0));
            nameField.setText((String) tableModel.getValueAt(row, 1));
            ageField.setText(tableModel.getValueAt(row, 2).toString());
            phoneField.setText((String) tableModel.getValueAt(row, 3));
            specField.setText((String) tableModel.getValueAt(row, 4));
            availField.setText((String) tableModel.getValueAt(row, 5));
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        phoneField.setText("");
        specField.setText("");
        availField.setText("");
    }
}
