/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */

// BASE CLASS - demonstrates Inheritance and Encapsulation
public abstract class Person {
    private String name;
    private int age;
    private String phone;

    public Person(String name, int age, String phone) {
        this.name = name;
        this.age = age;
        this.phone = phone;
    }

    // Getters and Setters (Encapsulation)
    public String getName()       { return name; }
    public void setName(String n) { this.name = n; }

    public int getAge()          { return age; }
    public void setAge(int a)    { this.age = a; }

    public String getPhone()          { return phone; }
    public void setPhone(String p)    { this.phone = p; }

    // Abstract method - Abstraction & Polymorphism
    public abstract String getRole();

    @Override
    public String toString() {
        return name + " | Age: " + age + " | Phone: " + phone;
    }
}
