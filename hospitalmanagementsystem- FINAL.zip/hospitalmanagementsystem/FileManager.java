/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Maryam
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// FILE HANDLING CLASS - reads and writes data to .txt files
public class FileManager {

    // ─── PATIENTS ────────────────────────────────────────────────
    public static void savePatients(List<Patient> patients) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("patients.txt"))) {
            for (Patient p : patients) {
                pw.println(p.toFileString());
            }
        } catch (IOException e) {
            System.out.println("Error saving patients: " + e.getMessage());
        }
    }

    public static List<Patient> loadPatients() {
        List<Patient> list = new ArrayList<>();
        File file = new File("patients.txt");
        if (!file.exists()) return list;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    list.add(Patient.fromFileString(line));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading patients: " + e.getMessage());
        }
        return list;
    }

    // ─── DOCTORS ─────────────────────────────────────────────────
    public static void saveDoctors(List<Doctor> doctors) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("doctors.txt"))) {
            for (Doctor d : doctors) {
                pw.println(d.toFileString());
            }
        } catch (IOException e) {
            System.out.println("Error saving doctors: " + e.getMessage());
        }
    }

    public static List<Doctor> loadDoctors() {
        List<Doctor> list = new ArrayList<>();
        File file = new File("doctors.txt");
        if (!file.exists()) return list;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    list.add(Doctor.fromFileString(line));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading doctors: " + e.getMessage());
        }
        return list;
    }

    // ─── APPOINTMENTS ─────────────────────────────────────────────
    public static void saveAppointments(List<Appointment> appointments) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("appointments.txt"))) {
            for (Appointment a : appointments) {
                pw.println(a.toFileString());
            }
        } catch (IOException e) {
            System.out.println("Error saving appointments: " + e.getMessage());
        }
    }

    public static List<Appointment> loadAppointments() {
        List<Appointment> list = new ArrayList<>();
        File file = new File("appointments.txt");
        if (!file.exists()) return list;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    list.add(Appointment.fromFileString(line));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading appointments: " + e.getMessage());
        }
        return list;
    }
}